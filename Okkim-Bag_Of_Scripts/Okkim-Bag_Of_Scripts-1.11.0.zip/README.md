Bag of Scripts is a code library made for my mods, released as standalone so it can be easily updated to accommodate future mods (and other modders!).

A list of scripts and their features are in the changelog.